export interface Permission {
  id: number
  name: string
  createdDate: string
  assignedTo: string[]
}
