<script setup lang="ts">
import TypographyHeadlines from '@/views/pages/typography/TypographyHeadlines.vue'
import TypographyTexts from '@/views/pages/typography/TypographyTexts.vue'
</script>

<template>
  <VRow>
    <VCol cols="12">
      <TypographyHeadlines />
    </VCol>

    <VCol cols="12">
      <TypographyTexts />
    </VCol>
  </VRow>
</template>
