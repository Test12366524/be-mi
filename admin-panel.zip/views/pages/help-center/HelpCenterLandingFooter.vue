<template>
  <div
    class="text-center"
    style="padding-block: 5.25rem;"
  >
    <VContainer>
      <h4 class="text-h4 text-center mb-4">
        Still need help?
      </h4>
      <p class="text-body-1 text-wrap">
        Our specialists are always happy to help.
        <br>
        Contact us during standard business hours or email us 24/7 and we'll get back to you.
      </p>
      <div class="d-flex justify-center gap-4 flex-wrap">
        <VBtn>Visit our community</VBtn>
        <VBtn>Contact us</VBtn>
      </div>
    </VContainer>
  </div>
</template>
